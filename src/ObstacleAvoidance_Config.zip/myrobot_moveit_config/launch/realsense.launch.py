from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # RealSense camera node
        Node(
            package='realsense2_camera',
            executable='realsense2_camera_node',
            name='realsense_camera',
            output='screen',
            # parameters=[{
            #     'align_depth.enable': True,
            #     'pointcloud.enable': True,
            #     'depth_module.profile': '640x480x15',
            #     'color_module.profile': '640x480x15',
            #     'enable_color': True,
            #     'enable_depth': True,
            #     'enable_accel': False,
            #     'enable_gyro': False
            # }],
            parameters=[{
                'align_depth.enable': True,
                'pointcloud.enable': True,
                'depth_module.profile': '640x480x15',
                'color_module.profile': '640x480x15',
                'enable_color': True,
                'enable_depth': True,
                'enable_accel': False,
                'enable_gyro': False,

                'depth_module.min_distance': 0.5,

                'filters': 'spatial,temporal,decimation',
                'decimation_filter.filter_magnitude': 2,
                'spatial_filter.smooth_alpha': 0.5,
                'spatial_filter.smooth_delta': 20,
                'temporal_filter.smooth_alpha': 0.4,
                'temporal_filter.smooth_delta': 20,
                'confidence.enable': True,
                'confidence_filter.confidence_threshold': 3,
                'use_sim_time': True,

            }],
        ),

        # Static transform from 'camera' to 'camera_link'
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='static_tf_camera_to_camera_link',
            arguments=['0', '0', '0', '0', '-1.57', '1.57', 'camera', 'camera_link'],
            output='screen',
        ),
    ])
