from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='octomap_server',
            executable='octomap_server_node',
            name='octomap_server',
            output='screen',
            parameters=[{
                'frame_id': 'camera_link',
                'resolution': 0.03,
                'sensor_model_max_range': 3.0,
                'delete_max_range_rays': True,
                'prob_hit': 0.7,
                'prob_miss': 0.4,
                'thres_min': 0.12,
                'thres_max': 0.97,
                'use_sim_time': True,
            }],
            remappings=[
                ('cloud_in', '/camera/realsense_camera/depth/color/points')
            ]
        )
    ])

